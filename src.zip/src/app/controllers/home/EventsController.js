(function() {

    angular
        .module('app')
        .controller('EventsController', [
            '$mdDialog',
            '$scope',
            'allDataService',
            'Upload',
            'ameLightbox',
            'ameLightboxDefaults',
            EventsController
        ]);

    function EventsController($mdDialog, $scope, allDataService, Upload, ameLightbox, ameLightboxDefaults) {
        var vm = this;
        $scope.events = {};
        //
        console.log('EventsController called');
        $scope.imagePath = ".././assets/images/pika.jpg";
        resetOptions();
        vm.items = [
            'http://placehold.it/350x150',
            'http://placehold.it/400x800',
            'http://placehold.it/1200x768',
            'http://placehold.it/500x100'
        ];

        $scope.showDemo = showDemo;
        $scope.resetOptions = resetOptions;

        function showDemo(targetEvent) {
            console.log('show demo called');
            ameLightbox.show(vm.items, angular.extend({}, vm.options, {
                targetEvent: vm.options.targetEvent ? targetEvent : undefined
            }));
        }

        function resetOptions() {
            vm.options = angular.copy(ameLightboxDefaults);
            vm.options.targetEvent = true;
        }
        //
        $scope.showReport = function(ev) {
            $mdDialog.show({
                    controller: 'DialogController',
                    templateUrl: 'app/views/partials/showReport.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: false,
                    fullscreen: false // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };
        $scope.showEvent = function(ev, index) {
            console.log(index);
            $mdDialog.show({
                    controller: 'SingleEventController',
                    templateUrl: 'app/views/partials/singleEvent.html',
                    parent: angular.element(document.body),
                    targetEvent : ev,
                    locals: {
                        events: $scope.events,
                        index : index
                    },
                    closeTo: '#left',
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: true // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };
        $scope.showAdvanced = function(ev) {
            $mdDialog.show({
                    controller: 'DialogController',
                    templateUrl: 'app/views/partials/addEvent.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: true // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        $scope.showUpdates = function(ev) {
            $mdDialog.show({
                    controller: 'DialogController',
                    templateUrl: 'app/views/partials/addEvent.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: true // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };
        $scope.addUpdate = function(ev) {
            $mdDialog.show({
                    controller: 'DialogController',
                    templateUrl: 'app/views/partials/addUpdate.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: true // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        $scope.showParticipants = function(ev) {
            $mdDialog.show({
                    controller: 'DialogController',
                    templateUrl: 'app/views/partials/showParticipants.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: true // Only for -xs, -sm breakpoints.
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };




        vm.activated = true;
        allDataService.get("events/Cultural")
            .then(function(tableData) {
                vm.tableData = [].concat(tableData.data)
                vm.activated = false;
                $scope.events = vm.tableData;
            });
    }

})();
